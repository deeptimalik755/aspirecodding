<template>
<div class="footerCls">
   <img  src="../assets/images/footer/Logo (2).svg" alt="" />
   <!-- <div>Freeze card</div> -->
   <img  src="../assets/images/footer/Credit.svg" alt="" />
   <!-- <div>Set spend limit</div> -->
   <img  src="../assets/images/footer/pay.svg" alt="" />
   <!-- <div>Add to GPay </div> -->
   <img src="../assets/images/footer/Payments.svg" alt="" />
   <!-- <div>Replace card</div> -->
   <img  src="../assets/images/footer/Account.svg" alt="" />
   <!-- <div>Cancel card</div> -->
</div>

</template>
