<template>
  <div>
    <div class="mobileScreen">
      <div class="logo">
        <img src="../assets/images/Logoo.svg" />
      </div>
      <div class="heading">
        <h4>Account Balance</h4>
      </div>
      <div class="balanceSection">
        <div class="account">$</div>
        <span>3,000</span>
        <div
          class="addcard"
          data-toggle="modal"
          data-target="#exampleModalCenter"
          @click="openModal"
        >
          <img src="../assets/images/box.svg" /><span> new card</span>
        </div>
      </div>
      <div class="tabs">
        <p>My Debit Cards</p>
      </div>
      <carousel
        :per-page="1"
        :mouse-drag="false"
        paginationActiveColor="#01D167"
        paginationColor="#000"
        @page-change="onPageChange"
      >
        <slide v-for="(todo, i) in cardDetails" :key="i">
          <div class="slides_container">
            <div class="showNmber">
              <img src="../assets/images/remove_red_eye.svg" /> Show Card Number
            </div>
            <div
              class="cardSlides"
              v-bind:class="{
                slideBG: toggled === true,
                SlideDisable: toggled === false,
              }"
            >
              <div class="sidelogo">
                <img src="../assets/images/Logo.svg" />
              </div>
              <div class="cardName">
                <p style="text-align: left">{{ todo.username }}</p>
                <!-- <h2 class="cardNumber" v-if="showNum==false">XXXX XXXX XXXX XXXX</h2> -->
                <h2 class="cardNumber">{{ todo.cardnumber }}</h2>
                <div class="cardDetails">
                  <p>Exp: {{ todo.carddate }}</p>
                  <!-- <p>2022</p> -->
                </div>
              </div>
              <div class="visalogo">
                <img src="../assets/images/VisaLogo.svg" />
              </div>
            </div>
          </div>
        </slide>
      </carousel>
    </div>
        <!-- remove card confirm poup  -->
    <div  class="modal-vue">
    <div class="overlay" v-if="showModal" @click="showModal = false"></div>
    <div class="modall" v-if="showModal">
      <button class="close" @click="showModal = false">x</button>
      <p>You want to proceed</p>
      <div class="">
        <button  class="btn btn-primary" @click="removeCard()"> Yes </button>
      </div>
    </div>
    </div>
    <div class="mainContainer">
      <div class="menu">
        <div class="menuicon menu-solution--flexbox">
          <ul>
            <li>
              <img
                src="../assets/images/menu/Freezecard.svg"
                alt=""
                @click="toggle"
              />
              <div>Freeze <span>card</span></div>
            </li>
            <li>
              <img
                src="../assets/images/menu/speed.svg"
                alt=""
               
              />
              <div>Set spend <span>limit</span></div>
            </li>
            <li>
              <img src="../assets/images/menu/GPay.svg" alt="" />
              <div>Add to <span>GPay </span></div>
            </li>
            <li>
              <img src="../assets/images/menu/Replacecard.svg" alt="" @click="showModal = true"/>
              <div>Replace <span>card</span></div>
            </li>
            <li>
              <img
                src="../assets/images/menu/Deactivate.svg"
                alt=""
                @click="confirmPopup()"
              />
              <div>Cancel <span>card</span></div>
            </li>
          </ul>
        </div>
      </div>
      
      <div class="detailsSection">
        <CardDetails />
      </div>
    </div>
    <div class="footerSection">
      <FooterMenu />
    </div>
    <!-- Modal -->
    <div
      class="modal fade"
      id="exampleModalCenter"
      tabindex="-1"
      role="dialog"
      aria-labelledby="exampleModalCenterTitle"
      aria-hidden="true"
      v-if="detailsModal==true"
    >
      <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLongTitle">Card Details</h5>
            <button
              type="button"
              class="close"
              data-dismiss="modal"
              aria-label="Close"
            >
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <form class="formcls">
              <div class="form-group">
                <label for="firstName">Card name</label>
                <input
                  type="text"
                  v-model="cardName"
                  class="form-control"
                  :class="{ 'is-invalid': submitted && $v.cardName.$error }"
                />
                <div
                  v-if="submitted && !$v.cardName.required"
                  class="invalid-feedback"
                >
                  Card name required
                </div>
              </div>
              <div class="form-group">
                <label for="lastName">User name</label>
                <input
                  type="text"
                  v-model="userName"
                  class="form-control"
                  :class="{ 'is-invalid': submitted && $v.userName.$error }"
                />
                <div
                  v-if="submitted && !$v.userName.required"
                  class="invalid-feedback"
                >
                  User Name is required
                </div>
              </div>
              <div class="form-group">
                <label for="text">Card number</label>
                <input
                  type="text"
                  :v-model="cardNumber"
                  :value="formatValue"
                  maxlength="19"
                  class="form-control"
                  @keypress="formatCreditCard($event)"
                  :class="{ 'is-invalid': submitted && $v.formatValue.$error }"
                />
                <div
                  v-if="submitted && !$v.formatValue.required"
                  class="invalid-feedback"
                >
                  Card Number is required
                </div>
              </div>
              <div class="form-group">
                <label for="date">Exp. Date</label>
                <input
                  type="text"
                  v-model="date"
                  class="form-control"
                  placeholder="MM / YY"
                  maxlength="7"
                  :class="{ 'is-invalid': submitted && $v.date.$error }"
                />
                <div
                  v-if="submitted && !$v.date.required"
                  class="invalid-feedback"
                >
                  Exp Date is required
                </div>
              </div>
            </form>
          </div>
          <div class="modal-footer">
            <button
              type="button"
              class="btn btn-secondary"
              data-dismiss="modal"
            >
              Close
            </button>
            <button type="button" class="btn btn-primary" @click="addCards">
              Submit
            </button>
          </div>
        </div>
      </div>
    </div>

  </div>
</template>
<script>
import { required } from "vuelidate/lib/validators";
import FooterMenu from "./FooterMenu.vue";
import CardDetails from "./CardDetails.vue";
import { Carousel, Slide } from "vue-carousel";
export default {
  name: "swiper-example-centered-auto",
  title: "Centered slides + Auto slides per view",
  components: {
    Carousel,
    Slide,
    CardDetails,
    FooterMenu,
  },
  data() {
    return {
      preview: null,
      image: null,
      preview_list: [],
      image_list: [],
      iconsList: [
        {
          title: "Freeze card",
          url: "../assets/images/menu/Freezecard.svg",
        },
        {
          title: "Set spend limit",
          url: "./assets/images/menu/speed.svg",
        },
        {
          title: "Add to GPay",
          url: "./assets/images/menu/GPay.svg",
        },
        {
          title: "Replace card",
          url: "./assets/images/menu/Replacecard.svg",
        },
        {
          title: "Cancel card",
          url: "./assets/images/menu/Deactivate.svg",
        },
      ],
      showModal: false,
      cardName: "",
      userName: "",
      cardNumber: "",
      date: "",
      submitted: false,
      formatValue: "",
      newTodo: "",
      cardDetails: [],
      slideIndex: null,
      freezCards: true,
      toggled: true,
      showNum: false,
      detailsModal:false
    };
  },

  //validations
  validations: {
    cardName: { required },
    userName: { required },
    formatValue: { required },
    date: { required },
  },
  methods: {
    
    //Add cards 
    addCards() {
      this.submitted = true;
      // stop here if form is invalid
      this.$v.$touch();
      if (this.$v.$invalid) {
        return;
      }
      this.cardDetails.push({
        cardname: this.cardName,
        username: this.userName,
        cardnumber: this.formatValue,
        carddate: this.date,
        completed: false,
      });
      this.cardName = "";
      this.userName = "";
      this.cardName = "";
      this.formatValue = "";
      this.date = "";
      this.detailsModal=false
      const parsed = JSON.stringify(this.cardDetails);
      localStorage.setItem("cardDetails", parsed);
    },
    openModal() {
      this.detailsModal = true;
    },

    confirmPopup(){
      this.showModal=true
    },
   
    //card format
    formatCreditCard($event) {
      if ($event.target.value.length < 19) {
        this.formatValue = $event.target.value
          .replace(/\W/gi, "")
          .replace(/(.{4})/g, "$1 ");
      }
    },

   //carousel event 
    onPageChange(currentPage) {
      this.slideIndex = currentPage;
    },

 //remove card
    removeCard() {
      this.cardDetails.splice(this.slideIndex, 1);
      localStorage.setItem("cardDetails", JSON.stringify(this.cardDetails));
      this.showModal=false;
    },

   
  // Active and deactive cards
    toggle: function () {
      this.toggled = !this.toggled;
    },
   

  },

  mounted() {
    {
      if (localStorage.getItem("cardDetails"))
        this.cardDetails = JSON.parse(localStorage.getItem("cardDetails"));
    }
  },
};
</script>

