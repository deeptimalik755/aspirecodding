<template>
<div class="accordion" id="accordionExample">
  <div class="card">
    <div class="card-header" id="headingOne">
      <h2 class="mb-0">
        
        <button class="btn btn-link btn-block text-left cardHeading" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
          <img  src="../assets/images/menu/Group 11889.svg" class="cardimg" alt="" /> Card Details
        </button>
      </h2>
    </div>
<div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
 <div class="card-body">
      No Data
      </div>
    </div>
  </div>
  <div class="card">
    <div class="card-header" id="headingTwo">
      <h2 class="mb-0">
        <button class="btn btn-link btn-block text-left collapsed cardHeading" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
           <img  src="../assets/images/menu/Group 11889 (1).svg" class="cardimg" alt="" />Recent Transaction
        </button>
      </h2>
    </div>
 <div id="collapseTwo" class="collapse show" aria-labelledby="headingTwo" data-parent="#accordionExample">
      
 <div class="card-body detailBox">
    <div class="row ">
    <div class="col-2 iconsImg" >
        <img  src="../assets/images/menu/file-storage.svg" class="iconsImgT" alt="" />
    </div>
    <div class="col-5 iconsDetails">  
        <h6>Freeze card</h6>
        <p class="para">Freeze card</p>
         <!-- <img src="../assets/images/icon.svg" alt=""  width="10px"/><span>Charged to debit card</span> -->
    </div>
    <div class="col-4 priceValue"> 
        <span>+ S$ 150</span><img src="../assets/images/icon.svg" alt=""  width="10px"/>
    </div>
</div>
<div class="devider"></div>
<div class="row ">
    <div class="col-2 iconsImg1" >
        <img  src="../assets/images/menu/flights.svg"  class="iconsImgT" alt="" />
    </div>
    <div class="col-5 iconsDetails">  
        <h6>Freeze card</h6>
        <p class="para">Freeze card</p>
    </div>
    <div class="col-4 priceValue"> 
        <span>+ S$ 150</span><img src="../assets/images/icon.svg" alt=""  width="10px"/>
    </div>
</div>
<div class="devider"></div>
<div class="row ">
    <div class="col-2 iconsImg2" >
        <img  src="../assets/images/menu/megaphone.svg" class="iconsImgT" alt="" />
    </div>
    <div class="col-5 iconsDetails">  
        <h6>Freeze card</h6>
        <p class="para">Freeze card</p>
    </div>
    <div class="col-4 priceValue"> 
        <span>+ S$ 150</span><img src="../assets/images/icon.svg" alt=""  width="10px"/>
    </div>
</div>

      </div>
      
    </div>
    <div class="row Detailsbtn">
         <span>View all card transactions</span>
    </div>
  </div>
  <p v-for="(book, i) in books" :key="i">{{book.title}}</p>
</div>

</template>
<script>
 export default {
        name: "cardDetails",
        props:{
          cardDetails:Array
        }
    }
</script>
