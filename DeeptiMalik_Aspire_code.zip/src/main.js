import Vue from 'vue'
import App from './App.vue'
import VueCarousel from 'vue-carousel';
import "./assets/style.css"
import Vuelidate from 'vuelidate'
Vue.use(Vuelidate)
Vue.use(VueCarousel);

Vue.config.productionTip = false

new Vue({
  render: h => h(App),
}).$mount('#app')

